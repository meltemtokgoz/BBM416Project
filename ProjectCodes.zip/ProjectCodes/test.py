# MAIN
import cv2
import imutils
from keras.models import load_model
from PIL import Image, ImageDraw
import os
import numpy as np

camera = cv2.VideoCapture(0)

loaded_model = load_model("mymodel.model")
FRAME_SIZE = 100
top, right, bottom, left = 10, 350, 225, 590

_, first_frame = camera.read()


SAVE_PATH = "Outputs"
# camera.release()
flipped_gray = cv2.flip(first_frame, 1)
cropped_frame = flipped_gray[top:bottom, right:left]


img_count = 1
dictonary = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4, 'F': 5, 'G': 6, 'H': 7, 'I': 8, 'K': 9, 'L': 10, 'M': 11, 'N': 12,
             'O': 13, 'P': 14,  'Q': 15, 'R': 16, 'S': 17, 'T': 18, 'U': 19, 'V': 20, 'W': 21, 'X': 22, 'Y': 23, 'Z':24, 'J':25}
num_class = 26
out = ""
inverted_dictonary = dict(map(reversed, dictonary.items()))
string = ""


while True:

    _, frame = camera.read()
    gray_frame = cv2.flip(frame, 1)

    # gray_frame = cv2.cvtColor(gray_frame, cv2.COLOR_BGR2GRAY)
    # gray_frame = cv2.GaussianBlur(gray_frame, (35,35), 0)

    cropped_frame_2 = gray_frame[top:bottom, right:left]

    little_frame = cv2.absdiff(cropped_frame, cropped_frame_2)
    little_frame = cv2.cvtColor(little_frame, cv2.COLOR_BGR2GRAY)
    little_frame = cv2.GaussianBlur(little_frame, (11, 11), 0)
    _, little_frame = cv2.threshold(little_frame, 10, 255, cv2.THRESH_BINARY)

    cv2.rectangle(gray_frame, (left, top), (right, bottom), (0, 255, 0), 2)



    cv2.imshow("Gesture", little_frame)

    key = cv2.waitKey(1)
    if key == 27:
        break
    if key == ord('q'):
        break
    if key == ord('r'):
        cropped_frame = gray_frame[top:bottom, right:left]
    if key == ord('x'):
        string = ""

    # PREDICTION

    img = cv2.resize(little_frame, (FRAME_SIZE, FRAME_SIZE))

    img_array = np.array(img)

    t2 = np.expand_dims(img_array, axis=-1)
    t2 = np.expand_dims(t2, axis=0)

    p = loaded_model.predict(t2)
    p2 = np.argmax(p)
    out = inverted_dictonary[p2]

    # PREDICTION ENDS

    font = cv2.FONT_HERSHEY_SIMPLEX
    cv2.putText(gray_frame, out, (22, 34), font, 1, (200, 255, 255), 2, cv2.LINE_AA)
    cv2.putText(gray_frame, string, (22, 64), font, 1, (200, 255, 255), 2, cv2.LINE_AA)

    cv2.putText(gray_frame, "r: Reset;  s: Append;  q: Quit;  x:delete", (22, 470), font, 1, (200, 255, 255), 2, cv2.LINE_AA)

    cv2.imshow("Main Frame", gray_frame)
    if key == ord('s'):
        string = string + "" + out



       

camera.release()
cv2.destroyAllWindows()